using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - Social")]
	public class AN_FB_LogIn : FsmStateAction {

		public string scopes = "email,publish_actions";


		public FsmEvent successEvent;
		public FsmEvent failEvent;
		

		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}

			if(SPFacebook.instance.IsLoggedIn) {
				OnSuccess();
				return;
			}

			SPFacebook.instance.Init();

			SPFacebook.instance.addEventListener(FacebookEvents.AUTHENTICATION_FAILED,  			OnFail);
			SPFacebook.instance.addEventListener(FacebookEvents.AUTHENTICATION_SUCCEEDED,   		OnSuccess);

			SPFacebook.instance.Login(scopes);


		}

		private void RemoveListeners() {
			SPFacebook.instance.removeEventListener(FacebookEvents.POST_FAILED,  			OnFail);
			SPFacebook.instance.removeEventListener(FacebookEvents.POST_SUCCEEDED,   		OnSuccess);
		}

		private void OnFail() {
			Fsm.Event(failEvent);
			RemoveListeners();
			Finish();
		}
		
		private void OnSuccess() {

			if(!SPFacebook.instance.IsLoggedIn) {
				OnFail();
				return;
			}

			Fsm.Event(successEvent);
			RemoveListeners();
			Finish();
		}

	}
}


