using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - Social")]
	public class AN_FB_Post : FsmStateAction {

		public FsmString link;
		public FsmString linkName;
		public FsmString linkCaption;
		public FsmString linkDescription;
		public FsmString pictureUrl;


		public FsmEvent successEvent;
		public FsmEvent failEvent;
		

		public override void OnEnter() {


			SPFacebook.instance.addEventListener(FacebookEvents.POST_FAILED,  			OnPostFailed);
			SPFacebook.instance.addEventListener(FacebookEvents.POST_SUCCEEDED,   		OnPostSuccses);

			SPFacebook.instance.Post (
				link: link.Value,
				linkName: linkName.Value,
				linkCaption: linkCaption.Value,
				linkDescription: linkDescription.Value,
				picture: pictureUrl.Value
			);


		}

		private void RemoveListners() {
			SPFacebook.instance.removeEventListener(FacebookEvents.POST_FAILED,  			OnPostFailed);
			SPFacebook.instance.removeEventListener(FacebookEvents.POST_SUCCEEDED,   		OnPostSuccses);
		}

		private void OnPostFailed() {
			Fsm.Event(failEvent);
			RemoveListners();
			Finish();
		}
		
		private void OnPostSuccses() {
			Fsm.Event(successEvent);
			RemoveListners();
			Finish();
		}

	}
}


