﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("Android Native - Notifications")]
	public class AN_CancelLocalNotification : FsmStateAction {

		public FsmInt notificationId;


				
		public override void OnEnter() {
			AndroidNotificationManager.instance.CancelLocalNotification(notificationId.Value);
			Finish ();
		}
	}
}
